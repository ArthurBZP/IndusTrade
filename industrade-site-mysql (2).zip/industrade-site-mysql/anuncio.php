<?php require_once __DIR__ . "/sessao.php"; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Torno Mecânico Romi TND 360 | Industrade</title>
  <meta name="description" content="Torno Mecânico Romi TND 360, ano 2015, revisado. Anúncio com fotos, especificações e contato direto com o vendedor na Industrade.">
  <link rel="preconnect" href="https://images.unsplash.com">
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="css/header.css">
  <link rel="stylesheet" href="css/mobile.css">
</head>
<body>

  <a class="skip-link" href="#conteudo-principal">Pular para o conteúdo principal</a>

  <header class="site-header">
    <div class="header-inner">

      <a class="logo" href="index.php" aria-label="Industrade — página inicial">
        <img class="logo-mark" src="img/Engrenagem no logo.png" width="36" height="36" alt="" aria-hidden="true">
        <span class="logo-text">Industrade</span>
      </a>

      <!--form class="search-form" role="search" action="/busca" method="get">
        <label class="visually-hidden" for="busca-maquinario">Buscar por palavra-chave, marca ou modelo</label>
        <input
          type="search"
          id="busca-maquinario"
          name="q"
          placeholder="Buscar por palavra-chave, marca ou modelo…"
          autocomplete="off"
        >
        <button type="submit" aria-label="Buscar">
          <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false">
            <circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="2"></circle>
            <line x1="15.5" y1="15.5" x2="21" y2="21" stroke="currentColor" stroke-width="2" stroke-linecap="round"></line>
          </svg>
        </button>
      </form-->

      <input type="checkbox" id="menu-toggle" class="menu-toggle-input">
      <label for="menu-toggle" class="menu-toggle-label" aria-hidden="false">
        <span class="visually-hidden">Abrir menu de navegação</span>
        <span class="menu-icon"></span>
      </label>

      <nav class="primary-nav" aria-label="Navegação principal">
        <!--ul>
          <li><a href="index.php#comprar">Comprar</a></li>
          <li><a href="index.php#vender">Vender</a></li>
          <li><a href="index.php#trocar">Trocar</a></li>
          <li><a href="index.php#categorias">Categorias</a></li>
        </ul-->
        <?php include __DIR__ . "/nav_cta.php"; ?>
      </nav>

    </div>
  </header>

  <main id="conteudo-principal">

    <div class="section-inner">
      <nav class="trilha-nav" aria-label="Trilha de navegação">
        <a href="index.php">Início</a> /
        <a href="index.php#vitrine">Metalmecânica</a> /
        <span class="trilha-atual">Torno Mecânico Romi TND 360</span>
      </nav>
    </div>

    <section class="anuncio" aria-labelledby="anuncio-titulo">
      <div class="section-inner anuncio-grid">

        <div class="anuncio-principal">

          <div class="anuncio-galeria">
            <input type="radio" name="galeria" id="galeria-1" class="galeria-radio" checked>
            <input type="radio" name="galeria" id="galeria-2" class="galeria-radio">
            <input type="radio" name="galeria" id="galeria-3" class="galeria-radio">

            <div class="galeria-principal">
              <img id="foto-1" class="galeria-foto" src="https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=900&q=80" alt="Torno mecânico Romi TND 360, vista frontal completa">
              <img id="foto-2" class="galeria-foto" src="https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=900&h=675&fit=crop&crop=left&q=80" alt="Torno mecânico Romi TND 360, detalhe do painel de comando">
              <img id="foto-3" class="galeria-foto" src="https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=900&h=675&fit=crop&crop=right&q=80" alt="Torno mecânico Romi TND 360, detalhe do barramento e castanha">
            </div>

            <div class="galeria-miniaturas">
              <label for="galeria-1" class="miniatura">
                <span class="visually-hidden">Ver foto 1 de 3</span>
                <img src="https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=200&q=80" alt="" loading="lazy">
              </label>
              <label for="galeria-2" class="miniatura">
                <span class="visually-hidden">Ver foto 2 de 3</span>
                <img src="https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=200&h=150&fit=crop&crop=left&q=80" alt="" loading="lazy">
              </label>
              <label for="galeria-3" class="miniatura">
                <span class="visually-hidden">Ver foto 3 de 3</span>
                <img src="https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=200&h=150&fit=crop&crop=right&q=80" alt="" loading="lazy">
              </label>
            </div>
          </div>

          <div class="anuncio-tags">
            <span class="tag tag-venda">Venda</span>
            <span class="tag tag-negociavel">Valor negociável</span>
          </div>

          <h1 id="anuncio-titulo" class="anuncio-titulo">Torno Mecânico Romi TND 360</h1>
          <p class="anuncio-meta">Ano 2015 · Revisado · Sorocaba/SP · Publicado há 3 dias</p>

          <div class="anuncio-descricao">
            <h2>Descrição</h2>
            <p>
              Torno mecânico Romi TND 360 com manutenção preventiva em dia e laudo técnico
              disponível. Equipamento de uso industrial, ideal para usinagem de peças de médio
              porte. Conjunto de castanhas e ferramental incluso na negociação. Máquina
              armazenada em galpão coberto, funcionando normalmente, sem histórico de acidentes
              ou sinistros.
            </p>
          </div>

          <div class="anuncio-specs">
            <h2>Especificações</h2>
            <dl class="specs-lista">
              <div>
                <dt>Marca</dt>
                <dd>Romi</dd>
              </div>
              <div>
                <dt>Modelo</dt>
                <dd>TND 360</dd>
              </div>
              <div>
                <dt>Ano de fabricação</dt>
                <dd>2015</dd>
              </div>
              <div>
                <dt>Condição</dt>
                <dd>Revisado</dd>
              </div>
              <div>
                <dt>Horas de uso estimadas</dt>
                <dd>8.200 h</dd>
              </div>
              <div>
                <dt>Alimentação</dt>
                <dd>220V trifásico</dd>
              </div>
              <div>
                <dt>Categoria</dt>
                <dd>Metalmecânica</dd>
              </div>
              <div>
                <dt>Localização</dt>
                <dd>Sorocaba/SP</dd>
              </div>
            </dl>
          </div>

        </div>

        <aside class="anuncio-lateral">

          <div class="anuncio-card-preco">
            <p class="anuncio-preco">R$ 68.500</p>
            <p class="anuncio-preco-nota">Aceita negociação de valores</p>
            <div class="anuncio-badges">
              <span class="badge">Aceita troca</span>
              <span class="badge">Frete a combinar</span>
            </div>
            <a class="btn btn-primary anuncio-cta" href="pagamento.php">Comprar</a>
            <a class="btn btn-outline-preto anuncio-cta" href="#vendedor">Conversar com o Vendedor</a>
          </div>

          <div class="vendedor-card" id="vendedor">
            <div class="vendedor-cabecalho">
              <span class="vendedor-avatar" aria-hidden="true">MA</span>
              <div>
                <p class="vendedor-nome">Marli Andrade</p>
                <p class="vendedor-local">Metalúrgica Andrade · Sorocaba/SP</p>
              </div>
            </div>

            <div class="vendedor-avaliacao">
              <span class="engrenagens" role="img" aria-label="Avaliação: 4,5 de 5 engrenagens">
                <span class="engrenagem-item"><img src="img/Engrenagem no logo.png" alt="" width="18" height="18"></span>
                <span class="engrenagem-item"><img src="img/Engrenagem no logo.png" alt="" width="18" height="18"></span>
                <span class="engrenagem-item"><img src="img/Engrenagem no logo.png" alt="" width="18" height="18"></span>
                <span class="engrenagem-item"><img src="img/Engrenagem no logo.png" alt="" width="18" height="18"></span>
                <span class="engrenagem-item"><img src="img/Engrenagem no logo metade.png" alt="" width="18" height="18"></span>
              </span>
              <span class="avaliacao-numero">4,5 de 5 · 128 avaliações</span>
            </div>

            <ul class="vendedor-info-lista">
              <li>Vendedor verificado</li>
              <li>Responde em até 2 horas</li>
              <li>Membro desde 2021</li>
            </ul>

            <a class="btn btn-outline-preto" href="/vendedor/metalurgica-andrade">Ver loja do vendedor</a>
          </div>

        </aside>

      </div>
    </section>

    <section class="similares" aria-labelledby="similares-titulo">
      <div class="section-inner">
        <h2 id="similares-titulo">Anúncios similares</h2>
        <div class="cards-grid">

          <article class="card-maquina">
            <img src="https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=600&h=450&fit=crop&crop=top&q=80" alt="Torno CNC Nardini em oficina de metalmecânica" loading="lazy">
            <div class="card-conteudo">
              <div class="card-tags">
                <span class="tag tag-venda">Venda</span>
              </div>
              <h3>Torno CNC Nardini Logic 175</h3>
              <p class="card-meta">Ano 2017 · Bom estado</p>
              <p class="card-preco">R$ 79.900</p>
            </div>
          </article>

          <article class="card-maquina">
            <img src="https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=600&h=450&fit=crop&crop=bottom&q=80" alt="Torno revólver industrial em oficina de metalmecânica" loading="lazy">
            <div class="card-conteudo">
              <div class="card-tags">
                <span class="tag tag-troca">Aceita troca</span>
              </div>
              <h3>Torno Revólver Romi T 240</h3>
              <p class="card-meta">Ano 2013 · Revisado</p>
              <p class="card-preco">R$ 54.000</p>
            </div>
          </article>

          <article class="card-maquina">
            <img src="https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=600&h=450&fit=crop&crop=left&q=80" alt="Retífica cilíndrica industrial em oficina de metalmecânica" loading="lazy">
            <div class="card-conteudo">
              <div class="card-tags">
                <span class="tag tag-venda">Venda</span>
              </div>
              <h3>Retífica Cilíndrica Sulmecânica</h3>
              <p class="card-meta">Ano 2010 · Operacional</p>
              <p class="card-preco">Sob consulta</p>
            </div>
          </article>

          <article class="card-maquina">
            <img src="https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=600&h=450&fit=crop&crop=right&q=80" alt="Fresadora universal industrial em oficina de metalmecânica" loading="lazy">
            <div class="card-conteudo">
              <div class="card-tags">
                <span class="tag tag-negociavel">Valor negociável</span>
              </div>
              <h3>Fresadora Universal Erlo</h3>
              <p class="card-meta">Ano 2016 · Revisado</p>
              <p class="card-preco">R$ 61.200</p>
            </div>
          </article>

        </div>
      </div>
    </section>

  </main>

  <footer class="site-footer">
    <div class="footer-inner">

      <div class="footer-coluna">
        <p class="footer-logo">Industrade</p>
        <p>Marketplace B2B para maquinário industrial usado.</p>
      </div>

      <nav class="footer-coluna" aria-label="Links úteis">
        <h3>Links úteis</h3>
        <ul>
          <li><a href="/sobre">Sobre nós</a></li>
          <li><a href="/ajuda">Central de ajuda</a></li>
          <li><a href="/frete">Políticas de frete e logística</a></li>
        </ul>
      </nav>

      <nav class="footer-coluna" aria-label="Termos legais">
        <h3>Termos legais</h3>
        <ul>
          <li><a href="/termos">Termos de uso</a></li>
          <li><a href="/privacidade">Política de privacidade</a></li>
          <li><a href="/regras-troca">Regras de troca</a></li>
        </ul>
      </nav>

      <div class="footer-coluna">
        <h3>Contato</h3>
        <address>
          <a href="mailto:contato@industrade.com.br">contato@industrade.com.br</a><br>
          <a href="tel:+551140028922">(11) 4002-8922</a>
        </address>
        <ul class="redes-sociais">
          <li><a href="https://instagram.com" aria-label="Industrade no Instagram">Instagram</a></li>
          <li><a href="https://linkedin.com" aria-label="Industrade no LinkedIn">LinkedIn</a></li>
        </ul>
      </div>

    </div>
    <p class="copyright">© 2026 Industrade. Todos os direitos reservados.</p>
  </footer>

  <script>
    // Fecha o menu mobile ao clicar em um link de navegação
    document.querySelectorAll('.primary-nav a').forEach(function (link) {
      link.addEventListener('click', function () {
        document.getElementById('menu-toggle').checked = false;
      });
    });
  </script>

</body>
</html>
