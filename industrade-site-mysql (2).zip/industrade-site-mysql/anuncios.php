<?php require_once __DIR__ . "/sessao.php"; ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Todos os anúncios | Industrade</title>
  <meta name="description" content="Veja todos os anúncios de maquinário industrial usado na Industrade e filtre por categoria e preço.">
  <link rel="preconnect" href="https://images.unsplash.com">
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="css/header.css">
  <link rel="stylesheet" href="css/mobile.css">
</head>
<body>

  <a class="skip-link" href="#conteudo-principal">Pular para o conteúdo principal</a>

  <header class="site-header">
    <div class="header-inner">

      <a class="logo" href="index.php" aria-label="Industrade — página inicial">
        <img class="logo-mark" src="img/Engrenagem no logo.png" width="36" height="36" alt="" aria-hidden="true">
        <span class="logo-text">Industrade</span>
      </a>

      <!--form class="search-form" role="search" action="/busca" method="get">
        <label class="visually-hidden" for="busca-maquinario">Buscar por palavra-chave, marca ou modelo</label>
        <input
          type="search"
          id="busca-maquinario"
          name="q"
          placeholder="Buscar por palavra-chave, marca ou modelo…"
          autocomplete="off"
        >
        <button type="submit" aria-label="Buscar">
          <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false">
            <circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="2"></circle>
            <line x1="15.5" y1="15.5" x2="21" y2="21" stroke="currentColor" stroke-width="2" stroke-linecap="round"></line>
          </svg>
        </button>
      </form-->

      <input type="checkbox" id="menu-toggle" class="menu-toggle-input">
      <label for="menu-toggle" class="menu-toggle-label" aria-hidden="false">
        <span class="visually-hidden">Abrir menu de navegação</span>
        <span class="menu-icon"></span>
      </label>

      <nav class="primary-nav" aria-label="Navegação principal">
        <!--ul>
          <li><a href="anuncios.php" aria-current="page">Comprar</a></li>
          <li><a href="index.php#vender">Vender</a></li>
          <li><a href="index.php#trocar">Trocar</a></li>
          <li><a href="index.php#categorias">Categorias</a></li>
        </ul-->
        <?php include __DIR__ . "/nav_cta.php"; ?>
      </nav>

    </div>
  </header>

  <main id="conteudo-principal">

    <div class="section-inner">
      <nav class="trilha-nav" aria-label="Trilha de navegação">
        <a href="index.php">Início</a> /
        <span class="trilha-atual">Todos os anúncios</span>
      </nav>
    </div>

    <section class="catalogo" aria-labelledby="catalogo-titulo">
      <div class="section-inner">
        <h1 id="catalogo-titulo" class="catalogo-titulo">Todos os anúncios</h1>
        <p class="catalogo-sub">Explore o maquinário disponível e refine a busca por categoria e faixa de preço.</p>

        <div class="catalogo-layout">

          <details class="filtros" id="filtros">
            <summary>Filtros</summary>
            <form class="filtros-form" id="form-filtros" novalidate>

              <fieldset>
                <legend>Categoria</legend>
            <label class="filtro-check"><input type="checkbox" name="categoria" value="metalmecanica"><span>Metalmecânica</span></label>
            <label class="filtro-check"><input type="checkbox" name="categoria" value="movimentacao"><span>Movimentação e logística</span></label>
            <label class="filtro-check"><input type="checkbox" name="categoria" value="embalagem"><span>Embalagem e plástico</span></label>
            <label class="filtro-check"><input type="checkbox" name="categoria" value="energia"><span>Energia</span></label>
              </fieldset>

              <fieldset>
                <legend>Preço (R$)</legend>
                <div class="filtro-preco">
                  <div class="campo-filtro">
                    <label for="preco-min">Mínimo</label>
                    <input type="number" id="preco-min" name="min" min="0" step="100" inputmode="numeric" placeholder="0">
                  </div>
                  <div class="campo-filtro">
                    <label for="preco-max">Máximo</label>
                    <input type="number" id="preco-max" name="max" min="0" step="100" inputmode="numeric" placeholder="Sem limite">
                  </div>
                </div>
                <label class="filtro-check">
                  <input type="checkbox" id="incluir-consulta" name="consulta" checked>
                  <span>Incluir anúncios “Sob consulta”</span>
                </label>
              </fieldset>

              <fieldset>
                <legend>Ordenar por</legend>
                <div class="campo-filtro">
                  <label class="visually-hidden" for="ordem">Ordenar anúncios</label>
                  <select id="ordem" name="ordem">
                    <option value="padrao">Relevância</option>
                    <option value="menor">Menor preço</option>
                    <option value="maior">Maior preço</option>
                  </select>
                </div>
              </fieldset>

              <button type="reset" class="btn btn-outline-preto filtros-limpar" id="limpar">Limpar filtros</button>
            </form>
          </details>

          <div class="catalogo-resultados">
            <p class="resultados-contagem" id="contagem" role="status" aria-live="polite"></p>

            <div class="cards-grid" id="lista-anuncios">

          <article class="card-maquina" data-categoria="metalmecanica" data-preco="68500" data-ordem="0">
            <a class="card-maquina-link" href="anuncio.php" aria-label="Ver anúncio: Torno Mecânico Romi TND 360, R$ 68.500">
              <img src="https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=600&q=80" alt="Torno Mecânico Romi TND 360 — máquina industrial de metalmecânica em oficina" loading="lazy">
              <div class="card-conteudo">
                <div class="card-tags">
                  <span class="tag tag-venda">Venda</span>
                </div>
                <h3>Torno Mecânico Romi TND 360</h3>
                <p class="card-meta">Ano 2015 · Revisado</p>
                <p class="card-preco">R$ 68.500</p>
              </div>
            </a>
          </article>

          <article class="card-maquina" data-categoria="metalmecanica" data-preco="79900" data-ordem="1">
            <a class="card-maquina-link" href="anuncio.php" aria-label="Ver anúncio: Torno CNC Nardini Logic 175, R$ 79.900">
              <img src="https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=600&h=450&fit=crop&crop=left&q=80" alt="Torno CNC Nardini Logic 175 — máquina industrial de metalmecânica em oficina" loading="lazy">
              <div class="card-conteudo">
                <div class="card-tags">
                  <span class="tag tag-venda">Venda</span>
                </div>
                <h3>Torno CNC Nardini Logic 175</h3>
                <p class="card-meta">Ano 2017 · Bom estado</p>
                <p class="card-preco">R$ 79.900</p>
              </div>
            </a>
          </article>

          <article class="card-maquina" data-categoria="metalmecanica" data-preco="" data-ordem="2">
            <a class="card-maquina-link" href="anuncio.php" aria-label="Ver anúncio: Retífica Cilíndrica Sulmecânica, Sob consulta">
              <img src="https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=600&h=450&fit=crop&crop=right&q=80" alt="Retífica Cilíndrica Sulmecânica — máquina industrial de metalmecânica em oficina" loading="lazy">
              <div class="card-conteudo">
                <div class="card-tags">
                  <span class="tag tag-venda">Venda</span>
                </div>
                <h3>Retífica Cilíndrica Sulmecânica</h3>
                <p class="card-meta">Ano 2010 · Operacional</p>
                <p class="card-preco">Sob consulta</p>
              </div>
            </a>
          </article>

          <article class="card-maquina" data-categoria="metalmecanica" data-preco="61200" data-ordem="3">
            <a class="card-maquina-link" href="anuncio.php" aria-label="Ver anúncio: Fresadora Universal Erlo, R$ 61.200">
              <img src="https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=600&h=450&fit=crop&crop=top&q=80" alt="Fresadora Universal Erlo — máquina industrial de metalmecânica em oficina" loading="lazy">
              <div class="card-conteudo">
                <div class="card-tags">
                  <span class="tag tag-negociavel">Valor negociável</span>
                </div>
                <h3>Fresadora Universal Erlo</h3>
                <p class="card-meta">Ano 2016 · Revisado</p>
                <p class="card-preco">R$ 61.200</p>
              </div>
            </a>
          </article>

          <article class="card-maquina" data-categoria="movimentacao" data-preco="42900" data-ordem="4">
            <a class="card-maquina-link" href="anuncio.php" aria-label="Ver anúncio: Empilhadeira Hyster H2.5FT, R$ 42.900">
              <img src="https://images.unsplash.com/photo-1601058268499-e52658b8bb88?w=600&q=80" alt="Empilhadeira Hyster H2.5FT — equipamento de movimentação e logística em galpão" loading="lazy">
              <div class="card-conteudo">
                <div class="card-tags">
                  <span class="tag tag-troca">Aceita troca</span>
                </div>
                <h3>Empilhadeira Hyster H2.5FT</h3>
                <p class="card-meta">Ano 2018 · Bom estado</p>
                <p class="card-preco">R$ 42.900</p>
              </div>
            </a>
          </article>

          <article class="card-maquina" data-categoria="movimentacao" data-preco="138000" data-ordem="5">
            <a class="card-maquina-link" href="anuncio.php" aria-label="Ver anúncio: Ponte Rolante Konecranes 5 t, R$ 138.000">
              <img src="https://images.unsplash.com/photo-1601058268499-e52658b8bb88?w=600&h=450&fit=crop&crop=left&q=80" alt="Ponte Rolante Konecranes 5 t — equipamento de movimentação e logística em galpão" loading="lazy">
              <div class="card-conteudo">
                <div class="card-tags">
                  <span class="tag tag-venda">Venda</span>
                </div>
                <h3>Ponte Rolante Konecranes 5 t</h3>
                <p class="card-meta">Ano 2014 · Revisado</p>
                <p class="card-preco">R$ 138.000</p>
              </div>
            </a>
          </article>

          <article class="card-maquina" data-categoria="movimentacao" data-preco="18500" data-ordem="6">
            <a class="card-maquina-link" href="anuncio.php" aria-label="Ver anúncio: Esteira Transportadora Modular 6 m, R$ 18.500">
              <img src="https://images.unsplash.com/photo-1601058268499-e52658b8bb88?w=600&h=450&fit=crop&crop=right&q=80" alt="Esteira Transportadora Modular 6 m — equipamento de movimentação e logística em galpão" loading="lazy">
              <div class="card-conteudo">
                <div class="card-tags">
                  <span class="tag tag-negociavel">Valor negociável</span>
                </div>
                <h3>Esteira Transportadora Modular 6 m</h3>
                <p class="card-meta">Ano 2019 · Bom estado</p>
                <p class="card-preco">R$ 18.500</p>
              </div>
            </a>
          </article>

          <article class="card-maquina" data-categoria="movimentacao" data-preco="23800" data-ordem="7">
            <a class="card-maquina-link" href="anuncio.php" aria-label="Ver anúncio: Paleteira Elétrica Still EXU 16, R$ 23.800">
              <img src="https://images.unsplash.com/photo-1601058268499-e52658b8bb88?w=600&h=450&fit=crop&crop=top&q=80" alt="Paleteira Elétrica Still EXU 16 — equipamento de movimentação e logística em galpão" loading="lazy">
              <div class="card-conteudo">
                <div class="card-tags">
                  <span class="tag tag-venda">Venda</span>
                </div>
                <h3>Paleteira Elétrica Still EXU 16</h3>
                <p class="card-meta">Ano 2020 · Seminovo</p>
                <p class="card-preco">R$ 23.800</p>
              </div>
            </a>
          </article>

          <article class="card-maquina" data-categoria="embalagem" data-preco="" data-ordem="8">
            <a class="card-maquina-link" href="anuncio.php" aria-label="Ver anúncio: Injetora Plástica Haitian MA1200, Sob consulta">
              <img src="https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=600&q=80" alt="Injetora Plástica Haitian MA1200 — máquina industrial de embalagem e plástico" loading="lazy">
              <div class="card-conteudo">
                <div class="card-tags">
                  <span class="tag tag-venda">Venda</span>
                </div>
                <h3>Injetora Plástica Haitian MA1200</h3>
                <p class="card-meta">Ano 2012 · Operacional</p>
                <p class="card-preco">Sob consulta</p>
              </div>
            </a>
          </article>

          <article class="card-maquina" data-categoria="embalagem" data-preco="34500" data-ordem="9">
            <a class="card-maquina-link" href="anuncio.php" aria-label="Ver anúncio: Envasadora Automática de Líquidos, R$ 34.500">
              <img src="https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=600&h=450&fit=crop&crop=left&q=80" alt="Envasadora Automática de Líquidos — máquina industrial de embalagem e plástico" loading="lazy">
              <div class="card-conteudo">
                <div class="card-tags">
                  <span class="tag tag-troca">Aceita troca</span>
                </div>
                <h3>Envasadora Automática de Líquidos</h3>
                <p class="card-meta">Ano 2017 · Revisado</p>
                <p class="card-preco">R$ 34.500</p>
              </div>
            </a>
          </article>

          <article class="card-maquina" data-categoria="embalagem" data-preco="9800" data-ordem="10">
            <a class="card-maquina-link" href="anuncio.php" aria-label="Ver anúncio: Seladora Térmica Contínua, R$ 9.800">
              <img src="https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=600&h=450&fit=crop&crop=right&q=80" alt="Seladora Térmica Contínua — máquina industrial de embalagem e plástico" loading="lazy">
              <div class="card-conteudo">
                <div class="card-tags">
                  <span class="tag tag-venda">Venda</span>
                </div>
                <h3>Seladora Térmica Contínua</h3>
                <p class="card-meta">Ano 2018 · Bom estado</p>
                <p class="card-preco">R$ 9.800</p>
              </div>
            </a>
          </article>

          <article class="card-maquina" data-categoria="embalagem" data-preco="87000" data-ordem="11">
            <a class="card-maquina-link" href="anuncio.php" aria-label="Ver anúncio: Extrusora de Filme Plástico Carnevalli, R$ 87.000">
              <img src="https://images.unsplash.com/photo-1581092160607-ee22621dd758?w=600&h=450&fit=crop&crop=top&q=80" alt="Extrusora de Filme Plástico Carnevalli — máquina industrial de embalagem e plástico" loading="lazy">
              <div class="card-conteudo">
                <div class="card-tags">
                  <span class="tag tag-negociavel">Valor negociável</span>
                </div>
                <h3>Extrusora de Filme Plástico Carnevalli</h3>
                <p class="card-meta">Ano 2011 · Revisado</p>
                <p class="card-preco">R$ 87.000</p>
              </div>
            </a>
          </article>

          <article class="card-maquina" data-categoria="energia" data-preco="91000" data-ordem="12">
            <a class="card-maquina-link" href="anuncio.php" aria-label="Ver anúncio: Gerador Diesel Stemac 180 kVA, R$ 91.000">
              <img src="https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=600&q=80" alt="Gerador Diesel Stemac 180 kVA — equipamento industrial de geração de energia" loading="lazy">
              <div class="card-conteudo">
                <div class="card-tags">
                  <span class="tag tag-troca">Aceita troca</span>
                </div>
                <h3>Gerador Diesel Stemac 180 kVA</h3>
                <p class="card-meta">Ano 2019 · Revisado</p>
                <p class="card-preco">R$ 91.000</p>
              </div>
            </a>
          </article>

          <article class="card-maquina" data-categoria="energia" data-preco="27600" data-ordem="13">
            <a class="card-maquina-link" href="anuncio.php" aria-label="Ver anúncio: Compressor de Parafuso Schulz 20 hp, R$ 27.600">
              <img src="https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=600&h=450&fit=crop&crop=left&q=80" alt="Compressor de Parafuso Schulz 20 hp — equipamento industrial de geração de energia" loading="lazy">
              <div class="card-conteudo">
                <div class="card-tags">
                  <span class="tag tag-venda">Venda</span>
                </div>
                <h3>Compressor de Parafuso Schulz 20 hp</h3>
                <p class="card-meta">Ano 2016 · Bom estado</p>
                <p class="card-preco">R$ 27.600</p>
              </div>
            </a>
          </article>

          <article class="card-maquina" data-categoria="energia" data-preco="31200" data-ordem="14">
            <a class="card-maquina-link" href="anuncio.php" aria-label="Ver anúncio: Transformador a Óleo 150 kVA, R$ 31.200">
              <img src="https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=600&h=450&fit=crop&crop=right&q=80" alt="Transformador a Óleo 150 kVA — equipamento industrial de geração de energia" loading="lazy">
              <div class="card-conteudo">
                <div class="card-tags">
                  <span class="tag tag-negociavel">Valor negociável</span>
                </div>
                <h3>Transformador a Óleo 150 kVA</h3>
                <p class="card-meta">Ano 2013 · Operacional</p>
                <p class="card-preco">R$ 31.200</p>
              </div>
            </a>
          </article>

          <article class="card-maquina" data-categoria="energia" data-preco="58900" data-ordem="15">
            <a class="card-maquina-link" href="anuncio.php" aria-label="Ver anúncio: Grupo Gerador Cummins 75 kVA, R$ 58.900">
              <img src="https://images.unsplash.com/photo-1621905251189-08b45d6a269e?w=600&h=450&fit=crop&crop=top&q=80" alt="Grupo Gerador Cummins 75 kVA — equipamento industrial de geração de energia" loading="lazy">
              <div class="card-conteudo">
                <div class="card-tags">
                  <span class="tag tag-troca">Aceita troca</span>
                </div>
                <h3>Grupo Gerador Cummins 75 kVA</h3>
                <p class="card-meta">Ano 2015 · Revisado</p>
                <p class="card-preco">R$ 58.900</p>
              </div>
            </a>
          </article>

            </div>

            <div class="sem-resultados" id="sem-resultados" hidden>
              <h2>Nenhum anúncio encontrado</h2>
              <p>Tente ampliar a faixa de preço ou selecionar outras categorias.</p>
              <button type="button" class="btn btn-primary" id="limpar-vazio">Limpar filtros</button>
            </div>
          </div>

        </div>
      </div>
    </section>

  </main>

  <footer class="site-footer">
    <div class="footer-inner">

      <div class="footer-coluna">
        <p class="footer-logo">Industrade</p>
        <p>Marketplace B2B para maquinário industrial usado.</p>
      </div>

      <nav class="footer-coluna" aria-label="Links úteis">
        <h3>Links úteis</h3>
        <ul>
          <li><a href="/sobre">Sobre nós</a></li>
          <li><a href="/ajuda">Central de ajuda</a></li>
          <li><a href="/frete">Políticas de frete e logística</a></li>
        </ul>
      </nav>

      <nav class="footer-coluna" aria-label="Termos legais">
        <h3>Termos legais</h3>
        <ul>
          <li><a href="/termos">Termos de uso</a></li>
          <li><a href="/privacidade">Política de privacidade</a></li>
          <li><a href="/regras-troca">Regras de troca</a></li>
        </ul>
      </nav>

      <div class="footer-coluna">
        <h3>Contato</h3>
        <address>
          <a href="mailto:contato@industrade.com.br">contato@industrade.com.br</a><br>
          <a href="tel:+551140028922">(11) 4002-8922</a>
        </address>
        <ul class="redes-sociais">
          <li><a href="https://instagram.com" aria-label="Industrade no Instagram">Instagram</a></li>
          <li><a href="https://linkedin.com" aria-label="Industrade no LinkedIn">LinkedIn</a></li>
        </ul>
      </div>

    </div>
    <p class="copyright">© 2026 Industrade. Todos os direitos reservados.</p>
  </footer>

  <script>
    // Fecha o menu mobile ao clicar em um link de navegação
    document.querySelectorAll('.primary-nav a').forEach(function (link) {
      link.addEventListener('click', function () {
        document.getElementById('menu-toggle').checked = false;
      });
    });
  </script>
  <script src="js/anuncios.js"></script>

</body>
</html>
