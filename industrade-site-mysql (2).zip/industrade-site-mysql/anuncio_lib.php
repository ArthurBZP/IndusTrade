<?php
// Funções e listas compartilhadas pelo cadastro/edição/exclusão de anúncios.

const CONDICOES_ITEM = ["Novo", "Seminovo", "Usado", "Revisado", "Para peças"];
const CONSERVACOES   = ["Excelente", "Bom", "Regular", "Necessita reparos"];
const UNIDADES       = ["Unidade", "Quilograma (kg)", "Tonelada (t)", "Metro (m)", "Litro (L)", "Caixa", "Pallet"];

function e($v) { return htmlspecialchars((string)($v ?? ""), ENT_QUOTES, "UTF-8"); }

// A tabela ANUNCIO tem uma única coluna (estado_conservacao, 30 caracteres) para
// "Condição do item" + "Estado de conservação". Guardamos os dois juntos: "Usado / Bom".
// (Maior combinação possível: "Para peças / Necessita reparos" = 30 caracteres.)
function codificarEstado($condicaoItem, $conservacao) {
    return $condicaoItem . " / " . $conservacao;
}
function decodificarEstado($texto) {
    $partes = explode(" / ", (string)$texto, 2);
    if (count($partes) === 2 && in_array($partes[0], CONDICOES_ITEM, true) && in_array($partes[1], CONSERVACOES, true)) {
        return [$partes[0], $partes[1]];
    }
    return ["", ""];    // anúncios antigos/de teste com outro formato
}

// Devolve o id da categoria (cria na primeira vez, se ainda não existir).
function obterCategoria(PDO $pdo, $tipo) {
    $stmt = $pdo->prepare("SELECT id_categoria FROM CATEGORIA WHERE tipo = ? ORDER BY id_categoria LIMIT 1");
    $stmt->execute([$tipo]);
    $id = $stmt->fetchColumn();
    if ($id) return (int)$id;
    $pdo->prepare("INSERT INTO CATEGORIA (tipo) VALUES (?)")->execute([$tipo]);
    return (int)$pdo->lastInsertId();
}

// Gera as <option> de um <select> marcando a escolhida.
function opcoes(array $lista, $atual) {
    $html = '<option value="">Selecione</option>';
    foreach ($lista as $o) {
        $html .= '<option' . ($o === $atual ? ' selected' : '') . '>' . e($o) . '</option>';
    }
    return $html;
}
