<?php
$inst = [
    "chave" => "regras-troca", "titulo" => "Regras de troca", "selo" => "Termos legais",
    "descricao" => "Como funciona a troca de equipamentos entre empresas na Industrade e o que fazer quando o produto não é como anunciado.",
    "intro" => "Na Industrade uma empresa pode oferecer um equipamento para venda ou para troca. Esta página explica como a troca funciona e o que fazer se algo não sair como o esperado.",
];
require __DIR__ . "/institucional_topo.php";
?>
      <section class="inst-secao" style="margin-top:0">
        <h2>Como funciona uma troca</h2>
        <p>A troca (permuta) é negociada diretamente entre as duas empresas. Use <strong>Conversar com o Vendedor</strong> no anúncio para ver o e-mail e o telefone e propor o que você oferece em troca.</p>
        <p>A troca <strong>não passa pelo sistema de compra e pagamento</strong> do site: por isso não gera pedido nem permite avaliação. Registre o acordo por escrito.</p>
      </section>

      <div class="inst-grid">
        <div class="inst-card"><h3>Antes de trocar</h3><ul class="inst-lista"><li>Compare estado, ano e valor aproximado dos dois equipamentos.</li><li>Peça fotos e, se possível, vistoria presencial.</li><li>Confira o perfil e as avaliações da outra empresa.</li></ul></div>
        <div class="inst-card"><h3>No acordo</h3><ul class="inst-lista"><li>Defina se há torna (diferença paga em dinheiro).</li><li>Combine prazos, nota fiscal e transporte (veja <a href="frete.php">Frete e logística</a>).</li><li>Documente tudo por escrito.</li></ul></div>
      </div>

      <section class="inst-secao">
        <h2>Produto diferente do anunciado</h2>
        <ol class="inst-lista">
          <li>Entre em contato com o vendedor e envie fotos que mostrem a divergência.</li>
          <li>Tente chegar a um acordo: ajuste de preço, reparo, troca ou devolução.</li>
          <li>Se não resolver ou houver suspeita de golpe, escreva para <a href="mailto:industrade@gmail.com?subject=Den%C3%BAncia%20de%20an%C3%BAncio%20%E2%80%94%20Industrade">industrade@gmail.com</a> com o link do anúncio e as provas.</li>
          <li>Se a compra foi feita pelo site, avalie o vendedor para alertar outras empresas.</li>
        </ol>
      </section>
<?php require __DIR__ . "/institucional_base.php"; ?>
