<?php
$inst = [
    "chave" => "termos", "titulo" => "Termos de uso", "selo" => "Termos legais",
    "descricao" => "Regras para usar a Industrade: cadastro, anúncios, compras, condutas não permitidas e denúncias.",
    "intro" => "Estes termos explicam, em linguagem simples, as regras para usar a Industrade. Ao criar uma conta e usar o site, a empresa concorda com elas.",
];
require __DIR__ . "/institucional_topo.php";
?>
      <section class="inst-secao" style="margin-top:0">
        <h2>1. Quem pode usar</h2>
        <p>A Industrade é voltada a empresas. O cadastro é feito com o CNPJ, e a empresa é responsável pelas informações que informa e por tudo que é feito na sua conta. Mantenha sua senha em sigilo.</p>
      </section>
      <section class="inst-secao">
        <h2>2. Anúncios</h2>
        <p>Quem anuncia é o único responsável pelo que publica e deve garantir que o equipamento ou recurso existe, está em seu poder e corresponde às fotos, ao estado e às especificações informadas.</p>
        <ul class="inst-lista">
          <li>É proibido publicar informações falsas ou enganosas, fotos que não sejam do produto ou itens de origem ilegal.</li>
          <li>Preço fixo é o valor da compra; preço negociável pode ser discutido com o vendedor; “sob consulta” é combinado direto.</li>
          <li>O vendedor pode editar, pausar ou excluir os próprios anúncios a qualquer momento.</li>
        </ul>
      </section>
      <section class="inst-secao">
        <h2>3. Compras e pagamento</h2>
        <p>Ao confirmar uma compra, o pedido é registrado e o anúncio passa a constar como vendido. <strong>Nesta versão o pagamento do site é uma simulação:</strong> nenhum valor é cobrado ou transferido pela plataforma, e os dados de pagamento digitados não são enviados nem guardados. A forma real de pagamento e a entrega devem ser combinadas diretamente entre comprador e vendedor (veja <a href="frete.php">Frete e logística</a>).</p>
      </section>
      <section class="inst-secao">
        <h2>4. Avaliações</h2>
        <p>Somente quem realizou uma compra pode avaliar o vendedor, uma vez por pedido. As avaliações devem ser verdadeiras e respeitosas; conteúdo ofensivo pode ser removido.</p>
      </section>
      <section class="inst-secao">
        <h2>5. Condutas não permitidas</h2>
        <ul class="inst-lista">
          <li>Tentar aplicar golpes, pedir pagamentos fora do combinado ou usar dados de terceiros.</li>
          <li>Usar a plataforma para spam, assédio ou qualquer atividade ilegal.</li>
          <li>Tentar acessar contas de outras empresas ou comprometer a segurança do site.</li>
        </ul>
        <p>Contas e anúncios que descumprirem estas regras podem ser suspensos ou removidos.</p>
      </section>
      <section class="inst-secao">
        <h2>6. Denúncias</h2>
        <p>Produto com problema ou suspeita de golpe? Escreva para <a href="mailto:industrade@gmail.com?subject=Den%C3%BAncia%20de%20an%C3%BAncio%20%E2%80%94%20Industrade">industrade@gmail.com</a> e analisaremos o caso.</p>
      </section>
      <section class="inst-secao">
        <h2>7. Responsabilidade e mudanças</h2>
        <p>A Industrade facilita o contato entre empresas, mas o negócio fechado é de responsabilidade de quem compra e de quem vende. Estes termos podem ser atualizados; a versão em vigor é sempre a publicada nesta página.</p>
      </section>
      <p class="inst-atualizado">Última atualização: novembro de 2026. Este é um resumo informativo e não substitui orientação jurídica.</p>
<?php require __DIR__ . "/institucional_base.php"; ?>
