<?php
// Botões do canto direito do menu: muda conforme a pessoa estar logada ou não.
require_once __DIR__ . "/sessao.php";
if (isset($_SESSION["id"])):
    $nomeMenu = htmlspecialchars($_SESSION["nome"] ?? "Meu perfil", ENT_QUOTES, "UTF-8");
?>
        <div class="nav-cta">
          <a class="btn btn-ghost" href="perfil.php"><?php echo $nomeMenu; ?></a>
          <a class="btn btn-primary" href="logout.php">Sair</a>
        </div>
<?php else: ?>
        <div class="nav-cta">
          <a class="btn btn-ghost" href="login.php">Entrar</a>
          <a class="btn btn-primary" href="cadastro.php">Criar conta</a>
        </div>
<?php endif; ?>
