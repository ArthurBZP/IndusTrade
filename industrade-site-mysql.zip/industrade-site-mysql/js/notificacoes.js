/* Industrade — notificacoes.js
   Protótipo de vendas + notificações (sem backend), usando localStorage como
   "barramento" entre páginas/abas do navegador.

   Um único arquivo, dois papéis (cada um só roda na página certa):
   1) pagamento.php -> ao confirmar o pagamento, REGISTRA a venda.
   2) perfil.php    -> mostra o sino de notificações e a aba "Produtos Vendidos"
                        para o usuário vendedor.

   Em produção, o registro (1) vira um INSERT em PEDIDO/ITEM_PEDIDO e a leitura (2)
   vira uma consulta/WebSocket ao backend. As funções estão separadas para facilitar
   essa troca (ver Vendas.listar / Vendas.registrar). */
(function () {
  'use strict';

  var MODO_DEMO = true;                         // exibe o botão "Simular venda" no painel
  var CHAVE_VENDAS = 'industrade.vendas';       // [{id, produto, preco, vendedor, comprador, doc, pagamento, data}]
  var CHAVE_LIDAS = 'industrade.notif.lidas';   // [id, id, ...]

  // ---------- Acesso ao storage (tolerante a falhas/bloqueio) ----------
  function ler(chave) {
    try { return JSON.parse(localStorage.getItem(chave)) || []; } catch (e) { return []; }
  }
  function gravar(chave, valor) {
    try { localStorage.setItem(chave, JSON.stringify(valor)); return true; } catch (e) { return false; }
  }

  var Vendas = {
    listar: function () { return ler(CHAVE_VENDAS); },
    registrar: function (venda) {
      var todas = ler(CHAVE_VENDAS);
      venda.id = 'v' + Date.now() + '-' + Math.floor(Math.random() * 1000);
      venda.data = new Date().toISOString();
      todas.push(venda);
      gravar(CHAVE_VENDAS, todas);
      return venda;
    }
  };

  function normalizar(t) {
    return (t || '').toString().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim().toLowerCase();
  }
  function formatarData(iso, comHora) {
    var d = new Date(iso);
    if (isNaN(d)) return '';
    return comHora ? d.toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })
                   : d.toLocaleDateString('pt-BR');
  }
  var NOMES_PAGAMENTO = { pix: 'PIX', cartao: 'Cartão', boleto: 'Boleto' };

  /* ============================================================
     1) PAGAMENTO — registra a venda quando o pagamento é confirmado
     ============================================================ */
  var formPagamento = document.querySelector('form[data-destino] input[name="pagamento"]');
  var resumo = document.querySelector('.resumo-compra');
  if (formPagamento && resumo) {
    var form = formPagamento.closest('form');
    // Registrado DEPOIS do listener de forms.js; só grava se o formulário for válido
    // (mesma condição que faz o forms.js redirecionar).
    form.addEventListener('submit', function () {
      if (!form.checkValidity()) return;

      var strongs = resumo.querySelectorAll('strong');
      var meta = resumo.querySelector('.card-meta');
      var partes = (meta ? meta.textContent : '').replace(/^\s*Vendedor:\s*/i, '').split('·');
      var vendedor = (partes[1] || partes[0] || '').trim();

      function valorAtivo(ids) {
        for (var i = 0; i < ids.length; i++) {
          var el = document.getElementById(ids[i]);
          if (el && !el.disabled && el.value.trim()) return el.value.trim();
        }
        return '';
      }
      var radio = form.querySelector('input[name="pagamento"]:checked');

      Vendas.registrar({
        produto: strongs.length ? strongs[0].textContent.trim() : 'Produto',
        preco: strongs.length ? strongs[strongs.length - 1].textContent.trim() : '',
        vendedor: vendedor,
        comprador: valorAtivo(['pix_nome', 'cartao_nome', 'bol_razao']) || 'Comprador',
        doc: valorAtivo(['pix_doc', 'bol_doc', 'cartao_doc']),
        pagamento: radio ? radio.value : ''
      });
    });
  }

  /* ============================================================
     2) PERFIL — notificações + aba Produtos Vendidos
     ============================================================ */
  var sino = document.getElementById('sino-notificacoes');
  var listaVendidos = document.getElementById('lista-vendidos');
  if (!sino || !listaVendidos) return;

  var painel = document.getElementById('notif-painel');
  var badge = document.getElementById('notif-badge');
  var listaNotif = document.getElementById('notif-lista');
  var vazioNotif = document.getElementById('notif-vazio');
  var btnLidas = document.getElementById('notif-marcar-lidas');
  var btnVerVendidos = document.getElementById('notif-ver-vendidos');
  var btnSimular = document.getElementById('notif-simular');
  var live = document.getElementById('notif-live');
  var vendidosVazio = document.getElementById('vendidos-vazio');
  var abaVendidos = document.getElementById('aba-vendidos');
  var nomePerfil = normalizar((document.querySelector('.perfil-nome') || {}).textContent);
  var jaRenderizadas = {};   // ids de vendas já desenhadas (evita duplicar na aba)
  var idsConhecidos = null;  // para detectar vendas novas e avisar leitores de tela
  var iniciado = false;      // true após a primeira renderização (evita animar o que já existia)

  function vendasDoPerfil() {
    return Vendas.listar().filter(function (v) {
      var vend = normalizar(v.vendedor);
      return vend && nomePerfil && (vend === nomePerfil || vend.indexOf(nomePerfil) !== -1 || nomePerfil.indexOf(vend) !== -1);
    }).sort(function (a, b) { return a.data < b.data ? 1 : -1; });
  }

  function el(tag, classe, texto) {
    var e = document.createElement(tag);
    if (classe) e.className = classe;
    if (texto !== undefined) e.textContent = texto;
    return e;
  }

  // ---------- Notificações ----------
  function renderNotificacoes() {
    var vendas = vendasDoPerfil();
    var lidas = ler(CHAVE_LIDAS);
    var naoLidas = 0;
    listaNotif.textContent = '';

    vendas.forEach(function (v) {
      var lida = lidas.indexOf(v.id) !== -1;
      if (!lida) naoLidas++;
      var li = el('li', 'notif-item' + (lida ? '' : ' nao-lida'));
      li.appendChild(el('span', 'notif-ponto'));
      var texto = el('div', 'notif-texto');
      var p = el('p');
      p.appendChild(el('strong', '', v.comprador));
      p.appendChild(document.createTextNode(' comprou ' ));
      p.appendChild(el('strong', '', v.produto));
      p.appendChild(document.createTextNode(v.preco ? ' por ' + v.preco + '.' : '.'));
      texto.appendChild(p);
      texto.appendChild(el('span', 'notif-hora', formatarData(v.data, true) + (v.pagamento ? ' · ' + (NOMES_PAGAMENTO[v.pagamento] || v.pagamento) : '')));
      li.appendChild(texto);
      listaNotif.appendChild(li);
    });

    vazioNotif.hidden = vendas.length !== 0;
    badge.textContent = naoLidas > 9 ? '9+' : String(naoLidas);
    badge.hidden = naoLidas === 0;
    sino.setAttribute('aria-label', naoLidas
      ? 'Notificações: ' + naoLidas + (naoLidas === 1 ? ' nova' : ' novas')
      : 'Notificações: nenhuma nova');
    btnLidas.hidden = naoLidas === 0;

    // Avisa leitores de tela quando chega uma venda nova
    var ids = vendas.map(function (v) { return v.id; });
    if (idsConhecidos) {
      var novas = vendas.filter(function (v) { return idsConhecidos.indexOf(v.id) === -1; });
      if (novas.length) live.textContent = 'Nova venda: ' + novas[0].produto + ' foi comprado por ' + novas[0].comprador + '.';
    }
    idsConhecidos = ids;
  }

  function alternarPainel(abrir) {
    painel.hidden = !abrir;
    sino.setAttribute('aria-expanded', abrir ? 'true' : 'false');
  }
  sino.addEventListener('click', function (e) {
    e.stopPropagation();
    alternarPainel(painel.hidden);
  });
  document.addEventListener('click', function (e) {
    if (!painel.hidden && !painel.contains(e.target) && e.target !== sino) alternarPainel(false);
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && !painel.hidden) { alternarPainel(false); sino.focus(); }
  });
  btnLidas.addEventListener('click', function () {
    var lidas = ler(CHAVE_LIDAS);
    vendasDoPerfil().forEach(function (v) { if (lidas.indexOf(v.id) === -1) lidas.push(v.id); });
    gravar(CHAVE_LIDAS, lidas);
    renderNotificacoes();
  });
  btnVerVendidos.addEventListener('click', function () {
    alternarPainel(false);
    abaVendidos.click();            // reaproveita o script de abas já existente
    abaVendidos.focus();
  });

  // ---------- Aba Produtos Vendidos ----------
  function renderVendidos() {
    vendasDoPerfil().slice().reverse().forEach(function (v) {   // reverse + prepend => mais recente no topo
      if (jaRenderizadas[v.id]) return;
      jaRenderizadas[v.id] = true;

      var li = el('li', 'item-produto item-vendido' + (iniciado ? ' nova' : ''));
      var corpo = el('div');
      var h3 = el('h3', '', v.produto);
      h3.appendChild(el('span', 'tag-vendido', 'Vendido'));
      corpo.appendChild(h3);
      if (v.preco) corpo.appendChild(el('p', 'card-preco', v.preco));

      var dl = el('dl', 'vendido-dados');
      [['Comprador', v.comprador], ['Data da venda', formatarData(v.data)],
       ['Pagamento', NOMES_PAGAMENTO[v.pagamento] || v.pagamento || '—']].forEach(function (par) {
        var d = el('div');
        d.appendChild(el('dt', '', par[0]));
        d.appendChild(el('dd', '', par[1]));
        dl.appendChild(d);
      });
      corpo.appendChild(dl);
      li.appendChild(corpo);
      listaVendidos.insertBefore(li, listaVendidos.firstChild);
    });
    vendidosVazio.hidden = listaVendidos.children.length !== 0;
  }

  // ---------- Simulação (apenas demonstração do protótipo) ----------
  if (MODO_DEMO && btnSimular) {
    btnSimular.hidden = false;
    var compradores = ['Usinagem Torres Ltda.', 'Indústria Moraes Ltda.', 'Fabrica Alfa Metais ME', 'Logística Pereira'];
    btnSimular.addEventListener('click', function () {
      var titulos = document.querySelectorAll('#lista-produtos .item-produto');
      var item = titulos.length ? titulos[Math.floor(Math.random() * titulos.length)] : null;
      var nome = item ? item.querySelector('h3').textContent.trim() : 'Produto de demonstração';
      var preco = item ? item.querySelector('.card-preco').textContent.trim() : '';
      Vendas.registrar({
        produto: nome,
        preco: preco,
        vendedor: (document.querySelector('.perfil-nome') || {}).textContent.trim(),
        comprador: compradores[Math.floor(Math.random() * compradores.length)],
        doc: '',
        pagamento: ['pix', 'cartao', 'boleto'][Math.floor(Math.random() * 3)]
      });
      atualizar();
    });
  }

  function atualizar() { renderNotificacoes(); renderVendidos(); }

  // "Tempo real" no protótipo: outra aba/página que gravar uma venda dispara este evento
  window.addEventListener('storage', function (e) {
    if (e.key === CHAVE_VENDAS || e.key === CHAVE_LIDAS || e.key === null) atualizar();
  });
  // Ao voltar para a aba/página, reconsulta (cobre navegadores que atrasam o evento)
  document.addEventListener('visibilitychange', function () { if (!document.hidden) atualizar(); });
  window.addEventListener('pageshow', atualizar);

  atualizar();
  iniciado = true;
})();
