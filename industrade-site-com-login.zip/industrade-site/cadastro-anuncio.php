<?php include("protect.php"); ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Anunciar produto | Industrade</title>
  <meta name="description" content="Cadastre um novo anúncio de maquinário ou recurso na Industrade.">
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="css/header.css">
  <link rel="stylesheet" href="css/mobile.css">
  <link rel="stylesheet" href="css/forms.css">
</head>
<body>

  <a class="skip-link" href="#conteudo-principal">Pular para o conteúdo principal</a>

  <header class="site-header">
    <div class="header-inner">

      <a class="logo" href="index.html" aria-label="Industrade — página inicial">
        <img class="logo-mark" src="img/Engrenagem no logo.png" width="36" height="36" alt="" aria-hidden="true">
        <span class="logo-text">Industrade</span>
      </a>

      <!--form class="search-form" role="search" action="/busca" method="get">
        <label class="visually-hidden" for="busca-maquinario">Buscar por palavra-chave, marca ou modelo</label>
        <input
          type="search"
          id="busca-maquinario"
          name="q"
          placeholder="Buscar por palavra-chave, marca ou modelo…"
          autocomplete="off"
        >
        <button type="submit" aria-label="Buscar">
          <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false">
            <circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="2"></circle>
            <line x1="15.5" y1="15.5" x2="21" y2="21" stroke="currentColor" stroke-width="2" stroke-linecap="round"></line>
          </svg>
        </button>
      </form-->

      <input type="checkbox" id="menu-toggle" class="menu-toggle-input">
      <label for="menu-toggle" class="menu-toggle-label" aria-hidden="false">
        <span class="visually-hidden">Abrir menu de navegação</span>
        <span class="menu-icon"></span>
      </label>

      <nav class="primary-nav" aria-label="Navegação principal">
        <!--ul>
          <li><a href="index.html#comprar">Comprar</a></li>
          <li><a href="index.html#vender">Vender</a></li>
          <li><a href="index.html#trocar">Trocar</a></li>
          <li><a href="index.html#categorias">Categorias</a></li>
        </ul-->
        <div class="nav-cta">
          <a class="btn btn-ghost" href="login.php">Entrar</a>
          <a class="btn btn-primary" href="cadastro.html">Criar conta</a>
        </div>
      </nav>

    </div>
  </header>

  <main id="conteudo-principal" class="pagina-interna">
    <div class="section-inner">
      <h1 class="pagina-titulo">Anunciar produto</h1>
      <p class="pagina-sub">Preencha os dados do equipamento ou recurso que você quer vender ou trocar.</p>

      <form class="card-form card-medio" data-destino="perfil.php" novalidate>
        <fieldset>
          <legend>Informações gerais</legend>
          <div class="grade-campos">
          <div class="campo col-total">
            <label for="nome">Nome</label>
            <input type="text" id="nome" name="nome" required >
          </div>
          <div class="campo col-total">
            <label for="descricao">Descrição</label>
            <textarea id="descricao" name="descricao" required></textarea>
          </div>
          <div class="campo ">
            <label for="condicao">Condição do Item</label>
            <select id="condicao" name="condicao" required><option value="">Selecione</option><option>Novo</option><option>Seminovo</option><option>Usado</option><option>Revisado</option><option>Para peças</option></select>
          </div>
          <div class="campo ">
            <label for="conservacao">Estado de Conservação</label>
            <select id="conservacao" name="conservacao" required><option value="">Selecione</option><option>Excelente</option><option>Bom</option><option>Regular</option><option>Necessita reparos</option></select>
          </div>
          <div class="campo ">
            <label for="data">Data</label>
            <input type="date" id="data" name="data" required >
          </div>
          </div>
        </fieldset>

        <fieldset style="margin-top:var(--space-md)">
          <legend>Preço</legend>
          <div class="opcoes" style="max-width:20rem">
            <label class="opcao"><input type="radio" name="preco" value="fixo" data-alterna="preco" checked required><span>Fixo</span></label>
            <label class="opcao"><input type="radio" name="preco" value="negociavel" data-alterna="preco" required><span>Negociável</span></label>
          </div>
          <div class="grade-campos" style="margin-top:var(--space-sm)" data-painel-de="preco" data-painel="fixo">
          <div class="campo ">
            <label for="valor">Valor (R$)</label>
            <input type="number" id="valor" name="valor" required placeholder="0,00" min="0" step="0.01">
          </div>
          </div>
        </fieldset>

        <fieldset style="margin-top:var(--space-md)">
          <legend>Qual a categoria do seu Anúncio?</legend>
          <div class="opcoes" style="max-width:20rem">
            <label class="opcao"><input type="radio" name="categoria" value="maquinario" data-alterna="categoria" required><span>Maquinário</span></label>
            <label class="opcao"><input type="radio" name="categoria" value="recurso" data-alterna="categoria" required><span>Recurso</span></label>
          </div>

          <div class="grade-campos" style="margin-top:var(--space-sm)" data-painel-de="categoria" data-painel="maquinario" hidden>
          <div class="campo ">
            <label for="marca">Marca</label>
            <input type="text" id="marca" name="marca" required >
          </div>
          <div class="campo ">
            <label for="modelo">Modelo</label>
            <input type="text" id="modelo" name="modelo" required >
          </div>
          <div class="campo ">
            <label for="ano">Ano de Fabricação</label>
            <input type="number" id="ano" name="ano" required min="1900" max="2100">
          </div>
          <div class="campo ">
            <label for="peso_maq">Peso (kg)</label>
            <input type="number" id="peso_maq" name="peso_maq" required min="0" step="0.01">
          </div>
          <div class="campo ">
            <label for="dimensoes">Dimensões</label>
            <input type="text" id="dimensoes" name="dimensoes" required placeholder="C x L x A (cm)" >
          </div>
          <div class="campo ">
            <label for="voltagem">Voltagem</label>
            <input type="text" id="voltagem" name="voltagem" required placeholder="Ex.: 220V trifásico" >
          </div>
          </div>

          <div class="grade-campos" style="margin-top:var(--space-sm)" data-painel-de="categoria" data-painel="recurso" hidden>
          <div class="campo ">
            <label for="nome_recurso">Nome do recurso</label>
            <input type="text" id="nome_recurso" name="nome_recurso" required >
          </div>
          <div class="campo ">
            <label for="peso_rec">Peso (kg)</label>
            <input type="number" id="peso_rec" name="peso_rec" required min="0" step="0.01">
          </div>
          <div class="campo ">
            <label for="quantidade">Quantidade</label>
            <input type="number" id="quantidade" name="quantidade" required min="1">
          </div>
          <div class="campo ">
            <label for="unidade">Unidade de Medida</label>
            <select id="unidade" name="unidade" required><option value="">Selecione</option><option>Unidade</option><option>Quilograma (kg)</option><option>Tonelada (t)</option><option>Metro (m)</option><option>Litro (L)</option><option>Caixa</option><option>Pallet</option></select>
          </div>
          </div>
        </fieldset>

        <fieldset style="margin-top:var(--space-md)">
          <legend>Imagens</legend>
          <div id="imagens">
            <div class="imagem-linha">
              <div class="campo"><label for="img-url-1">Link (URL) da Imagem</label><input type="url" id="img-url-1" name="img_url[]" placeholder="https://..."></div>
              <div class="campo"><label for="img-leg-1">Legenda</label><input type="text" id="img-leg-1" name="img_legenda[]"></div>
            </div>
          </div>
          <button type="button" class="btn btn-ghost" id="add-imagem" style="border-color:var(--cor-preto)">+ Adicionar outra imagem</button>
        </fieldset>

        <div class="acoes-form">
          <a class="btn btn-ghost" href="perfil.php" style="border-color:var(--cor-preto)">Cancelar</a>
          <button type="submit" class="btn btn-primary btn-lg">Publicar anúncio</button>
        </div>
      </form>
    </div>
  </main>

  <footer class="site-footer">
    <div class="footer-inner">

      <div class="footer-coluna">
        <p class="footer-logo">Industrade</p>
        <p>Marketplace B2B para maquinário industrial usado.</p>
      </div>

      <nav class="footer-coluna" aria-label="Links úteis">
        <h3>Links úteis</h3>
        <ul>
          <li><a href="/sobre">Sobre nós</a></li>
          <li><a href="/ajuda">Central de ajuda</a></li>
          <li><a href="/frete">Políticas de frete e logística</a></li>
        </ul>
      </nav>

      <nav class="footer-coluna" aria-label="Termos legais">
        <h3>Termos legais</h3>
        <ul>
          <li><a href="/termos">Termos de uso</a></li>
          <li><a href="/privacidade">Política de privacidade</a></li>
          <li><a href="/regras-troca">Regras de troca</a></li>
        </ul>
      </nav>

      <div class="footer-coluna">
        <h3>Contato</h3>
        <address>
          <a href="mailto:contato@industrade.com.br">contato@industrade.com.br</a><br>
          <a href="tel:+551140028922">(11) 4002-8922</a>
        </address>
        <ul class="redes-sociais">
          <li><a href="https://instagram.com" aria-label="Industrade no Instagram">Instagram</a></li>
          <li><a href="https://linkedin.com" aria-label="Industrade no LinkedIn">LinkedIn</a></li>
        </ul>
      </div>

    </div>
    <p class="copyright">© 2026 Industrade. Todos os direitos reservados.</p>
  </footer>

  <script>
    // Fecha o menu mobile ao clicar em um link de navegação
    document.querySelectorAll('.primary-nav a').forEach(function (link) {
      link.addEventListener('click', function () {
        document.getElementById('menu-toggle').checked = false;
      });
    });
  </script>
  <script src="js/forms.js"></script>
  <script>
    var n = 1;
    document.getElementById('add-imagem').addEventListener('click', function () {
      n++;
      var d = document.createElement('div');
      d.className = 'imagem-linha';
      d.innerHTML = '<div class="campo"><label for="img-url-' + n + '">Link (URL) da Imagem</label><input type="url" id="img-url-' + n + '" name="img_url[]" placeholder="https://..."></div>' +
                    '<div class="campo"><label for="img-leg-' + n + '">Legenda</label><input type="text" id="img-leg-' + n + '" name="img_legenda[]"></div>';
      document.getElementById('imagens').appendChild(d);
    });
  </script>
</body>
</html>
