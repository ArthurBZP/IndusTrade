<?php
session_start();
include("conexao.php");

// Só aceita envio pelo formulário
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: login.php");
    exit;
}

// O campo vem com máscara (12.345.678/0001-90): guarda só os números
$cnpj  = preg_replace('/\D/', '', $_POST["cnpj"] ?? "");
$senha = $_POST["senha"] ?? "";

$stmt = $mysqli->prepare("SELECT id, nome, cnpj, senha FROM usuarios WHERE cnpj = ?");
if (!$stmt) {
    header("Location: login.php?error=server_error");
    exit;
}
$stmt->bind_param("s", $cnpj);
$stmt->execute();
$usuario = $stmt->get_result()->fetch_assoc();

if ($usuario && password_verify($senha, $usuario["senha"])) {
    session_regenerate_id(true);
    $_SESSION["id"]   = $usuario["id"];
    $_SESSION["nome"] = $usuario["nome"];
    // formata o CNPJ para exibir no perfil
    $_SESSION["cnpj"] = preg_replace('/^(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})$/', '$1.$2.$3/$4-$5', $usuario["cnpj"]);

    header("Location: perfil.php");
    exit;
}

header("Location: login.php?error=invalid_credentials");
exit;
