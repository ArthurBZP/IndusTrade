<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Se não estiver logado, manda para a tela de login
if (!isset($_SESSION["id"])) {
    header("Location: login.php");
    exit;
}
