<?php include("protect.php"); ?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Meu perfil | Industrade</title>
  <meta name="description" content="Perfil da empresa, produtos anunciados e pedidos na Industrade.">
  <link rel="stylesheet" href="css/styles.css">
  <link rel="stylesheet" href="css/header.css">
  <link rel="stylesheet" href="css/mobile.css">
  <link rel="stylesheet" href="css/forms.css">
</head>
<body>

  <a class="skip-link" href="#conteudo-principal">Pular para o conteúdo principal</a>

  <header class="site-header">
    <div class="header-inner">

      <a class="logo" href="index.html" aria-label="Industrade — página inicial">
        <img class="logo-mark" src="img/Engrenagem no logo.png" width="36" height="36" alt="" aria-hidden="true">
        <span class="logo-text">Industrade</span>
      </a>

      <!--form class="search-form" role="search" action="/busca" method="get">
        <label class="visually-hidden" for="busca-maquinario">Buscar por palavra-chave, marca ou modelo</label>
        <input
          type="search"
          id="busca-maquinario"
          name="q"
          placeholder="Buscar por palavra-chave, marca ou modelo…"
          autocomplete="off"
        >
        <button type="submit" aria-label="Buscar">
          <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true" focusable="false">
            <circle cx="10.5" cy="10.5" r="6.5" fill="none" stroke="currentColor" stroke-width="2"></circle>
            <line x1="15.5" y1="15.5" x2="21" y2="21" stroke="currentColor" stroke-width="2" stroke-linecap="round"></line>
          </svg>
        </button>
      </form-->

      <input type="checkbox" id="menu-toggle" class="menu-toggle-input">
      <label for="menu-toggle" class="menu-toggle-label" aria-hidden="false">
        <span class="visually-hidden">Abrir menu de navegação</span>
        <span class="menu-icon"></span>
      </label>

      <nav class="primary-nav" aria-label="Navegação principal">
        <!--ul>
          <li><a href="index.html#comprar">Comprar</a></li>
          <li><a href="index.html#vender">Vender</a></li>
          <li><a href="index.html#trocar">Trocar</a></li>
          <li><a href="index.html#categorias">Categorias</a></li>
        </ul-->
        <div class="nav-cta">
          <a class="btn btn-ghost" href="login.php">Entrar</a>
          <a class="btn btn-primary" href="cadastro.html">Criar conta</a>
        </div>
      </nav>

    </div>
  </header>

  <main id="conteudo-principal" class="pagina-interna">
    <div class="section-inner">
      <div class="card-form">
        <div class="perfil-topo">
          <div class="perfil-foto-bloco">
            <div class="perfil-foto" id="perfil-foto" aria-label="Foto de perfil">MA</div>
            <div>
              <h1 class="perfil-nome"><?php echo htmlspecialchars($_SESSION["nome"]); ?></h1>
              <p class="perfil-cnpj">CNPJ <?php echo htmlspecialchars($_SESSION["cnpj"]); ?></p>
              <label class="link-discreto" for="foto-input" style="display:inline-block;margin-top:0.25rem">Alterar foto</label>
              <input type="file" id="foto-input" accept="image/*" class="visually-hidden">
            </div>
          </div>
          <div class="perfil-acoes">
            <a class="btn btn-primary" href="cadastro-anuncio.php">Anunciar Produto</a>
            <a class="btn btn-outline-preto" href="pedidos.php">Meus Pedidos</a>
            <a class="btn btn-ghost" href="logout.php" style="border-color:var(--cor-preto)">Sair da conta</a>
          </div>
        </div>
      </div>

      <div class="card-form">
        <div class="abas" role="tablist" aria-label="Seções do perfil">
          <button class="aba" role="tab" id="aba-dados" aria-controls="painel-dados" aria-selected="true">Dados cadastrais</button>
          <button class="aba" role="tab" id="aba-produtos" aria-controls="painel-produtos" aria-selected="false">Produtos Anunciados</button>
        </div>

        <div id="painel-dados" role="tabpanel" aria-labelledby="aba-dados">
          <dl class="dados-lista">
            <div><dt>CNPJ</dt><dd>12.345.678/0001-90</dd></div>
            <div><dt>Razão Social</dt><dd>Andrade Metalúrgica Ltda.</dd></div>
            <div><dt>Nome Fantasia</dt><dd>Metalúrgica Andrade</dd></div>
            <div><dt>E-mail</dt><dd>contato@metalurgicaandrade.com.br</dd></div>
            <div><dt>Telefone</dt><dd>(15) 3333-4567</dd></div>
            <div><dt>CEP</dt><dd>18000-000</dd></div>
            <div><dt>Logradouro</dt><dd>Rua das Indústrias</dd></div>
            <div><dt>Número</dt><dd>450</dd></div>
            <div><dt>Complemento</dt><dd>Galpão 2</dd></div>
            <div><dt>Bairro</dt><dd>Distrito Industrial</dd></div>
            <div><dt>Cidade</dt><dd>Sorocaba</dd></div>
            <div><dt>UF</dt><dd>SP</dd></div>
          </dl>
        </div>

        <div id="painel-produtos" role="tabpanel" aria-labelledby="aba-produtos" hidden>
          <ul class="lista-produtos" id="lista-produtos">
          <li class="item-produto">
            <div>
              <h3>Torno Mecânico Romi TND 360</h3>
              <p class="card-meta">Maquinário · Ano 2015 · Revisado</p>
              <p class="card-preco">R$ 68.500</p>
            </div>
            <div class="item-acoes">
              <a class="btn btn-primary btn-sm" href="cadastro-anuncio.php">Editar</a>
              <button type="button" class="btn btn-perigo btn-sm" data-excluir>Excluir</button>
            </div>
          </li>
          <li class="item-produto">
            <div>
              <h3>Retífica Cilíndrica Sulmecânica</h3>
              <p class="card-meta">Maquinário · Ano 2010 · Operacional</p>
              <p class="card-preco">Sob consulta</p>
            </div>
            <div class="item-acoes">
              <a class="btn btn-primary btn-sm" href="cadastro-anuncio.php">Editar</a>
              <button type="button" class="btn btn-perigo btn-sm" data-excluir>Excluir</button>
            </div>
          </li>
          <li class="item-produto">
            <div>
              <h3>Chapas de aço carbono (lote)</h3>
              <p class="card-meta">Recurso · 40 unidades · Bom estado</p>
              <p class="card-preco">R$ 12.400</p>
            </div>
            <div class="item-acoes">
              <a class="btn btn-primary btn-sm" href="cadastro-anuncio.php">Editar</a>
              <button type="button" class="btn btn-perigo btn-sm" data-excluir>Excluir</button>
            </div>
          </li>
          </ul>
          <p class="vazio" id="produtos-vazio" hidden>Você ainda não tem produtos anunciados.</p>
        </div>
      </div>
    </div>
  </main>

  <footer class="site-footer">
    <div class="footer-inner">

      <div class="footer-coluna">
        <p class="footer-logo">Industrade</p>
        <p>Marketplace B2B para maquinário industrial usado.</p>
      </div>

      <nav class="footer-coluna" aria-label="Links úteis">
        <h3>Links úteis</h3>
        <ul>
          <li><a href="/sobre">Sobre nós</a></li>
          <li><a href="/ajuda">Central de ajuda</a></li>
          <li><a href="/frete">Políticas de frete e logística</a></li>
        </ul>
      </nav>

      <nav class="footer-coluna" aria-label="Termos legais">
        <h3>Termos legais</h3>
        <ul>
          <li><a href="/termos">Termos de uso</a></li>
          <li><a href="/privacidade">Política de privacidade</a></li>
          <li><a href="/regras-troca">Regras de troca</a></li>
        </ul>
      </nav>

      <div class="footer-coluna">
        <h3>Contato</h3>
        <address>
          <a href="mailto:contato@industrade.com.br">contato@industrade.com.br</a><br>
          <a href="tel:+551140028922">(11) 4002-8922</a>
        </address>
        <ul class="redes-sociais">
          <li><a href="https://instagram.com" aria-label="Industrade no Instagram">Instagram</a></li>
          <li><a href="https://linkedin.com" aria-label="Industrade no LinkedIn">LinkedIn</a></li>
        </ul>
      </div>

    </div>
    <p class="copyright">© 2026 Industrade. Todos os direitos reservados.</p>
  </footer>

  <script>
    // Fecha o menu mobile ao clicar em um link de navegação
    document.querySelectorAll('.primary-nav a').forEach(function (link) {
      link.addEventListener('click', function () {
        document.getElementById('menu-toggle').checked = false;
      });
    });
  </script>
  <script src="js/forms.js"></script>
  <script>
    // Abas
    var abas = document.querySelectorAll('.aba');
    abas.forEach(function (aba) {
      aba.addEventListener('click', function () {
        abas.forEach(function (a) {
          var ativa = a === aba;
          a.setAttribute('aria-selected', ativa);
          document.getElementById(a.getAttribute('aria-controls')).hidden = !ativa;
        });
      });
    });
    // Excluir anúncio (protótipo: remove da lista)
    document.querySelectorAll('[data-excluir]').forEach(function (b) {
      b.addEventListener('click', function () {
        if (!confirm('Excluir este anúncio?')) return;
        b.closest('.item-produto').remove();
        if (!document.querySelector('.item-produto')) document.getElementById('produtos-vazio').hidden = false;
      });
    });
    // Pré-visualização da foto de perfil
    document.getElementById('foto-input').addEventListener('change', function (e) {
      var f = e.target.files[0]; if (!f) return;
      var img = document.createElement('img');
      img.alt = 'Foto de perfil'; img.src = URL.createObjectURL(f);
      var box = document.getElementById('perfil-foto'); box.textContent = ''; box.appendChild(img);
    });
  </script>
</body>
</html>
