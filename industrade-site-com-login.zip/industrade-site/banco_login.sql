-- Rode no phpMyAdmin (aba SQL)
CREATE DATABASE IF NOT EXISTS industrade CHARACTER SET utf8mb4;
USE industrade;

CREATE TABLE IF NOT EXISTS usuarios (
    id    INT AUTO_INCREMENT PRIMARY KEY,
    nome  VARCHAR(150) NOT NULL,
    cnpj  VARCHAR(14)  NOT NULL UNIQUE,   -- somente números
    senha VARCHAR(255) NOT NULL           -- hash gerado com password_hash()
);
