<?php
// Rode UMA vez no navegador (http://localhost/industrade-site/criar_usuario.php)
// para criar um usuário de teste. Depois APAGUE este arquivo.
include("conexao.php");

$nome  = "Metalúrgica Andrade";
$cnpj  = "12345678000190";
$senha = password_hash("123456", PASSWORD_DEFAULT);

$stmt = $mysqli->prepare("INSERT INTO usuarios (nome, cnpj, senha) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $nome, $cnpj, $senha);

if ($stmt->execute()) {
    echo "Usuário criado! Faça login com CNPJ 12.345.678/0001-90 e senha 123456. Agora apague este arquivo.";
} else {
    echo "Erro: " . $mysqli->error;
}
