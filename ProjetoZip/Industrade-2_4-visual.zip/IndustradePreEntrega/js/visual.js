/* Industrade — visual.js
   Detalhes de interface que acompanham o css/visual.css:
   1) Cabeçalho ganha sombra quando a página rola
   2) Blocos abaixo da dobra aparecem com uma entrada suave
   3) O número de destaque ("60%") conta até o valor final
   4) A tecla Esc fecha o menu mobile

   Não mexe em formulários, dados nem nas rotas do PHP.
   Sem JavaScript (ou com "reduzir movimento" ligado no sistema), o site
   continua completo: só não há animação. */
(function () {
  'use strict';

  var raiz = document.documentElement;
  var reduzirMovimento = window.matchMedia &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var temObserver = 'IntersectionObserver' in window;

  // Elementos que entram com animação ao rolar a página
  var SELETOR_REVELAR = [
    '.categoria-card',
    '.card-maquina',
    '.selo',
    '.beneficios',
    '.depoimentos blockquote',
    '.item-produto',
    '.item-pedido',
    '.inst-card'
  ].join(',');

  var MAX_ESCALONAMENTO = 4;   // até 4 passos de atraso entre irmãos
  var PASSO_ATRASO_MS = 80;

  /* ---------- 1) Cabeçalho ao rolar ---------- */
  function iniciarCabecalho() {
    var cabecalho = document.querySelector('.site-header');
    if (!cabecalho) return;

    var aguardando = false;

    function atualizar() {
      aguardando = false;
      cabecalho.classList.toggle('is-scrolled', window.scrollY > 8);
    }

    function aoRolar() {
      if (aguardando) return;
      aguardando = true;
      window.requestAnimationFrame(atualizar);
    }

    window.addEventListener('scroll', aoRolar, { passive: true });
    atualizar();
  }

  /* ---------- 2) Entrada dos blocos ao rolar ---------- */
  function iniciarRevelar() {
    if (!temObserver || reduzirMovimento) return;

    var altura = window.innerHeight;
    var candidatos = Array.prototype.slice.call(document.querySelectorAll(SELETOR_REVELAR));

    // Só anima o que está abaixo da dobra: o que já está visível na abertura
    // da página nunca fica escondido.
    var abaixoDaDobra = candidatos.filter(function (el) {
      return el.getBoundingClientRect().top > altura * 0.9;
    });
    if (!abaixoDaDobra.length) return;

    var observador = new IntersectionObserver(function (entradas) {
      entradas.forEach(function (entrada) {
        if (!entrada.isIntersecting) return;
        var el = entrada.target;
        el.classList.add('visivel');
        observador.unobserve(el);

        // Depois da entrada, tira o atraso para o efeito de hover responder na hora
        window.setTimeout(function () { el.classList.add('revelado'); }, 900);
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.08 });

    abaixoDaDobra.forEach(function (el) {
      var irmaos = Array.prototype.filter.call(el.parentElement.children, function (outro) {
        return outro.matches(SELETOR_REVELAR);
      });
      var posicao = Math.min(irmaos.indexOf(el), MAX_ESCALONAMENTO);
      el.style.setProperty('--atraso', (posicao * PASSO_ATRASO_MS) + 'ms');
      el.setAttribute('data-revelar', '');
      observador.observe(el);
    });

    // Só liga o estilo de "escondido" depois que os elementos estão marcados
    raiz.classList.add('anima');
  }

  /* ---------- 3) Contador do número de destaque ---------- */
  function animarNumero(forte, valorFinal, sufixo) {
    var duracao = 1200;
    var inicio = null;

    function quadro(agora) {
      if (inicio === null) inicio = agora;
      var progresso = Math.min((agora - inicio) / duracao, 1);
      var suave = 1 - Math.pow(1 - progresso, 3);     // desacelera no final
      forte.textContent = Math.round(valorFinal * suave) + sufixo;
      if (progresso < 1) window.requestAnimationFrame(quadro);
    }

    window.requestAnimationFrame(quadro);
  }

  function iniciarContador() {
    if (!temObserver || reduzirMovimento) return;

    var forte = document.querySelector('.beneficio-numero strong');
    if (!forte) return;

    var casamento = /^(\d+)(\D*)$/.exec(forte.textContent.trim());
    if (!casamento) return;

    var textoFinal = forte.textContent.trim();
    var valorFinal = parseInt(casamento[1], 10);
    var sufixo = casamento[2];

    // Leitores de tela recebem o valor final de uma vez, sem ouvir a contagem
    var leitura = document.createElement('span');
    leitura.className = 'visually-hidden';
    leitura.textContent = textoFinal;
    forte.parentNode.insertBefore(leitura, forte);
    forte.setAttribute('aria-hidden', 'true');

    var observador = new IntersectionObserver(function (entradas) {
      if (!entradas[0].isIntersecting) return;
      observador.disconnect();
      animarNumero(forte, valorFinal, sufixo);
    }, { threshold: 0.6 });

    observador.observe(forte);
  }

  /* ---------- 4) Esc fecha o menu mobile ---------- */
  function iniciarMenu() {
    var caixa = document.getElementById('menu-toggle');
    if (!caixa) return;

    document.addEventListener('keydown', function (evento) {
      if (evento.key !== 'Escape' || !caixa.checked) return;
      caixa.checked = false;
      caixa.focus();   // o foco volta ao botão do menu (a caixa fica ligada ao rótulo)
    });
  }

  function iniciar() {
    iniciarCabecalho();
    iniciarRevelar();
    iniciarContador();
    iniciarMenu();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', iniciar);
  } else {
    iniciar();
  }
})();
