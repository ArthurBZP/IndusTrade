-- ============================================================================
-- INDUSTRADE - SCRIPT DDL (MySQL 8.0.16+ / MariaDB 10.2.1+)
-- Convertido a partir da versao Oracle.
--
-- Principais equivalencias:
--   NUMBER GENERATED ALWAYS AS IDENTITY  ->  INT NOT NULL AUTO_INCREMENT
--   VARCHAR2(n)                          ->  VARCHAR(n)
--   NUMBER(p,s)                          ->  DECIMAL(p,s)
--   NUMBER(1) / BOOLEAN                  ->  TINYINT(1)
--   DATE DEFAULT SYSDATE                 ->  DATETIME DEFAULT CURRENT_TIMESTAMP
--                                            (o DATE do Oracle guarda data + hora)
--   TIMESTAMP                            ->  DATETIME
--   LENGTH()                             ->  CHAR_LENGTH()
--
-- Obs.: as FKs exigem InnoDB (padrao do MySQL). Os CHECKs so sao aplicados a
-- partir do MySQL 8.0.16 (em versoes antigas sao aceitos, mas ignorados).
-- ============================================================================

CREATE DATABASE IF NOT EXISTS industrade
    DEFAULT CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE industrade;

-- 1) ENDERECO -------------------------------------------------------------
CREATE TABLE ENDERECO (
    id_endereco   INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    cep           VARCHAR(9)   NOT NULL,
    logradouro    VARCHAR(100) NOT NULL,
    numero        VARCHAR(10)  NOT NULL,
    complemento   VARCHAR(60),
    bairro        VARCHAR(80)  NOT NULL,
    cidade        VARCHAR(80)  NOT NULL,
    uf            CHAR(2)       NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2) EMPRESA ----------------------------------------------------------------
CREATE TABLE EMPRESA (
    cnpj              VARCHAR(14)  PRIMARY KEY,
    razao_social      VARCHAR(150) NOT NULL,
    nome_fantasia     VARCHAR(150) NOT NULL,
    email             VARCHAR(150) NOT NULL,
    telefone          VARCHAR(20)  NOT NULL,
    senha             VARCHAR(255)  NOT NULL,
    nome_responsavel  VARCHAR(100),
    data_cadastro     DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    verificada        TINYINT(1)    NOT NULL DEFAULT 0,
    id_endereco_fk    INT NOT NULL,

    CONSTRAINT uq_empresa_email UNIQUE (email),

    CONSTRAINT fk_empresa_endereco
        FOREIGN KEY (id_endereco_fk)
        REFERENCES ENDERECO (id_endereco),

    CONSTRAINT ck_empresa_cnpj      CHECK (CHAR_LENGTH(cnpj) = 14),
    CONSTRAINT ck_empresa_senha     CHECK (CHAR_LENGTH(senha) >= 8),
    CONSTRAINT ck_empresa_verificada CHECK (verificada IN (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4) CATEGORIA ---------------------------------------------------------------
CREATE TABLE CATEGORIA (
    id_categoria   INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    tipo           VARCHAR(60) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5) ANUNCIO -----------------------------------------------------------------
CREATE TABLE ANUNCIO (
    id_anuncio           INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome                 VARCHAR(150)  NOT NULL,
    descricao            VARCHAR(2000),
    estado_conservacao   VARCHAR(30),
    data_publicacao      DATE           NOT NULL,
    condicao             VARCHAR(20)   NOT NULL,
    valor                DECIMAL(12,2)   NOT NULL,
    tipo_preco           VARCHAR(12)   NOT NULL,
    cnpj_fk              VARCHAR(14)   NOT NULL,
    id_categoria_fk      INT NOT NULL,

    CONSTRAINT fk_anuncio_empresa 
        FOREIGN KEY (cnpj_fk)
        REFERENCES EMPRESA (cnpj),

    CONSTRAINT fk_anuncio_categoria 
        FOREIGN KEY (id_categoria_fk)
        REFERENCES CATEGORIA (id_categoria),

    CONSTRAINT ck_anuncio_tipo_preco
        CHECK (tipo_preco IN ('FIXO', 'NEGOCIAVEL')),

    CONSTRAINT ck_anuncio_condicao
        CHECK (condicao IN ('ATIVO', 'PAUSADO', 'VENDIDO', 'REMOVIDO'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6) MAQUINARIO (especializacao de ANUNCIO) ----------------------------------
CREATE TABLE MAQUINARIO (
    cod_maquinario   INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    marca            VARCHAR(80),
    modelo           VARCHAR(80),
    ano_fabricacao   SMALLINT UNSIGNED,
    peso             DECIMAL(10,2),
    dimensao         VARCHAR(60),
    voltagem         VARCHAR(20),
    id_anuncio_fk    INT NOT NULL,

    CONSTRAINT fk_maquinario_anuncio 
        FOREIGN KEY (id_anuncio_fk)
        REFERENCES ANUNCIO (id_anuncio)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7) RECURSO (especializacao de ANUNCIO) -------------------------------------
CREATE TABLE RECURSO (
    cod_recurso      INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nome             VARCHAR(120) NOT NULL,
    peso             DECIMAL(10,2),
    quantidade       DECIMAL(10,2)  NOT NULL,
    unidade_medida   VARCHAR(20)  NOT NULL,
    id_anuncio_fk    INT NOT NULL,

    CONSTRAINT fk_recurso_anuncio 
        FOREIGN KEY (id_anuncio_fk)
        REFERENCES ANUNCIO (id_anuncio)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8) IMAGEM -------------------------------------------------------------------
CREATE TABLE IMAGEM (
    id_imagem      INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    link           VARCHAR(500) NOT NULL,
    legenda        VARCHAR(120),
    id_anuncio_fk  INT NOT NULL,

    CONSTRAINT fk_imagem_anuncio 
        FOREIGN KEY (id_anuncio_fk)
        REFERENCES ANUNCIO (id_anuncio)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9) PEDIDO ---------------------------------------------------------------------
CREATE TABLE PEDIDO (
    id_pedido          INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    data_criacao       DATE          NOT NULL,
    condicao_atual       VARCHAR(20)  NOT NULL,
    valor_total        DECIMAL(12,2) NOT NULL DEFAULT 0,
    cnpj_comprador_fk  VARCHAR(14)  NOT NULL,

    CONSTRAINT fk_pedido_empresa 
        FOREIGN KEY (cnpj_comprador_fk)
        REFERENCES EMPRESA (cnpj),

    CONSTRAINT ck_pedido_condicao
        CHECK (condicao_atual IN ('CARRINHO', 'REALIZADO', 'ENVIADO', 'ENTREGUE', 'CANCELADO'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10) ITEM_PEDIDO (entidade associativa, PK composta) --------------------------
CREATE TABLE ITEM_PEDIDO (
    id_pedido_pk_fk        INT NOT NULL,
    id_anuncio_pk_fk       INT NOT NULL,
    quantidade             DECIMAL(10,2) NOT NULL,
    valor_unitario         DECIMAL(12,2) NOT NULL,

    CONSTRAINT pk_item_pedido PRIMARY KEY (id_pedido_pk_fk, id_anuncio_pk_fk),

    CONSTRAINT fk_item_pedido_pedido 
        FOREIGN KEY (id_pedido_pk_fk)
        REFERENCES PEDIDO (id_pedido),

    CONSTRAINT fk_item_pedido_anuncio 
        FOREIGN KEY (id_anuncio_pk_fk)
        REFERENCES ANUNCIO (id_anuncio)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11) HISTORICO_STATUS_PEDIDO ----------------------------------------------------
CREATE TABLE HISTORICO_STATUS_PEDIDO (
    id_historico   INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    condicao       VARCHAR(20)   NOT NULL,
    data_hora      DATETIME       NOT NULL,
    id_pedido_fk   INT NOT NULL,

    CONSTRAINT fk_historico_pedido 
        FOREIGN KEY (id_pedido_fk)
        REFERENCES PEDIDO (id_pedido)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12) MENSAGEM ---------------------------------------------------------------------
CREATE TABLE MENSAGEM (
    id_mensagem          INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    data_hora            DATETIME       NOT NULL,
    conteudo             VARCHAR(2000) NOT NULL,
    is_chatbot           TINYINT(1)     NOT NULL,
    cnpj_remetente_fk    VARCHAR(14)   NOT NULL,
    cnpj_destinatario_fk VARCHAR(14),
    id_anuncio_fk        INT NOT NULL,

    CONSTRAINT fk_mensagem_remetente 
        FOREIGN KEY (cnpj_remetente_fk)
        REFERENCES EMPRESA (cnpj),

    CONSTRAINT fk_mensagem_destinatario 
        FOREIGN KEY (cnpj_destinatario_fk)
        REFERENCES EMPRESA (cnpj),

    CONSTRAINT fk_mensagem_anuncio 
        FOREIGN KEY (id_anuncio_fk)
        REFERENCES ANUNCIO (id_anuncio),

    CONSTRAINT ck_mensagem_is_chatbot 
        CHECK (is_chatbot IN (0,1))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13) AVALIACAO -----------------------------------------------------------------------
CREATE TABLE AVALIACAO (
    id_avaliacao      INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    nota              DECIMAL(2,1)   NOT NULL,
    comentario        VARCHAR(1000),
    data_avaliacao    DATE          NOT NULL,
    cnpj_avaliador_fk VARCHAR(14)  NOT NULL,
    cnpj_avaliado_fk  VARCHAR(14)  NOT NULL,
    id_pedido_fk      INT NOT NULL,

    CONSTRAINT fk_avaliacao_avaliador 
        FOREIGN KEY (cnpj_avaliador_fk)
        REFERENCES EMPRESA (cnpj),

    CONSTRAINT fk_avaliacao_avaliado 
        FOREIGN KEY (cnpj_avaliado_fk)
        REFERENCES EMPRESA (cnpj),

    CONSTRAINT fk_avaliacao_pedido 
        FOREIGN KEY (id_pedido_fk)
        REFERENCES PEDIDO (id_pedido),

    CONSTRAINT ck_avaliacao_nota 
        CHECK (nota BETWEEN 0 AND 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;